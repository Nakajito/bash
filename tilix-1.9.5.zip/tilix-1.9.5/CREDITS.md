Credits
=======

I would like to thank the following people and organizations without
whom this project would not be where it is today. If I am missing anyone,
please feel free to let me know or update this file via a pull request.

* Gerald Nunn
* Philip Wolfer
* dsboger
* Egmont Koblinger
* Bilal Elmoussaoui
* Alex Diavatis
* Alex Whitman
* Boiethios
* Matthias Clausen
* Christian Herget
* Allan Day

While not directly contributing to Tilix, I would also like to thank the following
people and organizations for their contributions to projects without whose existence
Tilix would not exist.

* Christian Pesch for GTK VTE
* Mike Wey for GtkD
* The D Foundation
* Gnome Project, http://www.gnome.org
