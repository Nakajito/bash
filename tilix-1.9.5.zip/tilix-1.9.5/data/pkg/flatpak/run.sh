#! /bin/sh

flatpak run com.gexperts.Terminix