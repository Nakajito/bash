## Notice

This is an extract of some specific files from the [x11](https://github.com/nomad-software/x11) repository. This was done instead of linking to it via DUB because DUB isn't well supported by Linux distro's so add adding dub libraries is problematic.

Longer term this solution obviously does not scale, the hope is that DUB becomes better supported or an alternate build system like meson could be adapted to fit the bill.  
